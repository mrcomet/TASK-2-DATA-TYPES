#!/usr/bin/env python
# coding: utf-8

# # Q1.List Comprehensions

# In[1]:


if __name__ == '__main__':
    x = int(input())
    y = int(input())
    z = int(input())
    n = int(input())
    lis = []
    for i in range(x + 1):
        for j in range (y + 1):
            for k in range (z + 1):
                if i + j + k != n: 
                    lis.append([i,j,k])
print(lis)
                    


# # Q2.Nested Lists

# In[ ]:


Res =[]
scorel = []

if __name__ == '__main__':
    for _ in range(int(input())):
        name = input()
        score = float(input())
        Res+=[[name,score]]
        scorel+=[score]
    b=sorted(list(set(scorel)))[1] 

    for a,c in sorted(Res):
        if c==b:
            print(a)


# # Q3,Finding the percentage

# In[ ]:


if __name__ == '__main__':
    n = int(input())
    student_marks = {}
    for _ in range(n):
        name, *line = input().split()
        scores = list(map(float, line))
        student_marks[name] = scores
    query_name = input()

    if query_name in student_marks:
        x = ((float(student_marks[query_name][0]) + float(student_marks[query_name][1]) + float(student_marks[query_name][2])) / 3)
    
    print('%.2f' % x)


# # Q4.Lists

# In[ ]:


import sys

if __name__ == '__main__':
    N = int(input())

my_list = []
inputs  = []

for line in sys.stdin:
    inputs.append(line)

for item in inputs:
    if item[0:5] == 'print':
        print(my_list)
    elif item[0:2] == 'in':
        inserts = [s for s in item.split()][1:3]
        inserts = list(map(int, inserts))
        my_list.insert(inserts[0], inserts[1])
    elif item[0:3] == 'rem':
        inserts = list(map(int, [s for s in item.split()][1]))
        my_list.remove(inserts[0])
    elif item[0:2] == 'ap':
        inserts = list(map(int, [s for s in item.split()][1]))
        my_list.append(inserts[0])
    elif item[0:4] == 'sort':
        my_list.sort()
    elif item[0:3] == 'pop':
        my_list.pop()
    elif item[0:7] == 'reverse':
        my_list.reverse()


# # Q5.Tuple

# In[ ]:


n = raw_input()
print hash(tuple([int(i) for i in raw_input().split()]))


# # Q6.Introduction to Sets

# In[ ]:


def average(array):
    h = set(array)
    s = sum(h)
    n = len(h)
    return "{:.3f}".format(s/n)

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)


# # Q7. No idea

# In[ ]:


if __name__ == "__main__":
    happiness = 0
    n, m = map(int, input().strip().split(' '))
    arr = list(map(int, input().strip().split(' ')))
    
    good = set(map(int, input().strip().split(' ')))
    bad = set(map(int, input().strip().split(' ')))
    
    for el in arr:
        if el in good:
            happiness += 1
        elif el in bad:
            happiness -= 1
    
    print(happiness)


# # Q8.Symmetric Difference

# In[ ]:


if __name__ == "__main__":
    M = int(input().strip())
    set_m = set(map(int, input().strip().split(' ')))
    
    N = int(input().strip())
    set_n = set(map(int, input().strip().split(' ')))
    
    for el in sorted(set_m ^ set_n):
        print(el)


# # Q9.Set .add()

# In[ ]:


temp = set()
[temp.add(input()) for _ in range(int(input()))]
print(len(temp))


# # Q10.Set .discard(), .remove() & .pop()

# In[ ]:


n=int(input())

s = set(map(int,input().split()))

N=int(input())

for i in range(N) :

    choice=input().split()
    if choice[0]=="pop" :
        s.pop()
    elif choice[0]=="remove" :
        s.remove(int(choice[1]))
    elif choice[0]=="discard" :
        s.discard(int(choice[1]))

print (sum(s))


# # Q11 SET UNION 

# In[ ]:


a = input()
tmp = set(map(int,input().split()))
b = input()
tmp2 = set(map(int,input().split()))
print(len(tmp.union(tmp2)))


# # Q12 INTERSECTION

# In[ ]:


a = input()
tmp = set(map(int,input().split()))
b = input()
tmp2 = set(map(int,input().split()))
print(len(tmp.intersection(tmp2)))


# # Q13. DIFFERENCE

# In[ ]:


a = input()
tmp = set(map(int,input().split()))
b = input()
tmp2 = set(map(int,input().split()))
print(len(tmp-tmp2))

